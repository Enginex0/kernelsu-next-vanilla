#!/system/bin/sh
# Performance Tuning - Installation Script
# Runs during module installation via KernelSU/Magisk manager

SKIPUNZIP=1

ui_print "=========================================="
ui_print " Performance Tuning Module v1.0.0"
ui_print "=========================================="
ui_print ""
ui_print " BFQ I/O Scheduler Tuning:"
ui_print "   - slice_idle = 0"
ui_print "   - fifo_expire_sync = 80"
ui_print "   - fifo_expire_async = 150"
ui_print "   - back_seek_max = 32768"
ui_print "   - back_seek_penalty = 1"
ui_print ""
ui_print " Memory Optimizations:"
ui_print "   - swappiness = 100 (aggressive ZRAM)"
ui_print "   - vfs_cache_pressure = 50"
ui_print "   - page-cluster = 0 (single page ZRAM)"
ui_print "   - dirty_ratio = 30"
ui_print "   - dirty_background_ratio = 5"
ui_print ""

ui_print "[*] Extracting module files..."
unzip -o "$ZIPFILE" -x 'META-INF/*' -d "$MODPATH" >&2

if [ ! -f "$MODPATH/module.prop" ]; then
    ui_print "[!] Installation failed - module.prop missing"
    exit 1
fi

ui_print "[*] Setting permissions..."
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755

ui_print ""
ui_print "[+] Installation complete!"
ui_print "[*] Tuning will apply on next boot"
ui_print "[*] Logs: /data/local/tmp/perf_tuning.log"
ui_print ""
