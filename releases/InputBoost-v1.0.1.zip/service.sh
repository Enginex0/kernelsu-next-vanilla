#!/system/bin/sh
# Input Boost Daemon - Boot Service
# Starts the input boost daemon at boot

MODDIR=${0%/*}
LOGFILE="/data/local/tmp/input_boost.log"
PIDFILE="/data/local/tmp/input_boost.pid"
LOOPPIDFILE="/data/local/tmp/input_boost_loop.pid"
DAEMON="$MODDIR/input_boost_daemon.sh"

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] service.sh: $1" >> "$LOGFILE"
}

# Wait for boot to complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done
sleep 10

log_msg "Boot completed, starting input boost daemon"

# BUG 7 FIX: Kill any existing restart loop to prevent orphans
if [ -f "$LOOPPIDFILE" ]; then
    old_loop_pid=$(cat "$LOOPPIDFILE" 2>/dev/null)
    if [ -n "$old_loop_pid" ] && kill -0 "$old_loop_pid" 2>/dev/null; then
        log_msg "Killing existing restart loop (PID: $old_loop_pid)"
        kill "$old_loop_pid" 2>/dev/null
        sleep 1
    fi
    rm -f "$LOOPPIDFILE"
fi

# Kill any existing daemon instance
if [ -f "$PIDFILE" ]; then
    old_pid=$(cat "$PIDFILE" 2>/dev/null)
    if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
        log_msg "Killing existing daemon (PID: $old_pid)"
        kill "$old_pid" 2>/dev/null
        sleep 1
    fi
    rm -f "$PIDFILE"
fi

# Start daemon with restart-on-crash
(
    # BUG 7 FIX: Track the restart loop PID
    echo $$ > "$LOOPPIDFILE"

    while true; do
        log_msg "Starting daemon: $DAEMON"
        sh "$DAEMON"
        exit_code=$?

        if [ $exit_code -eq 0 ]; then
            log_msg "Daemon exited normally"
            break
        fi

        log_msg "Daemon crashed (exit code: $exit_code), restarting in 5s"
        sleep 5
    done

    rm -f "$LOOPPIDFILE"
) &
